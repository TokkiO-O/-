export default {
  async fetch(request, env, ctx) {
    // 1. 定义通用的 CORS 头部，允许任何跨域请求
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Expose-Headers": "*"
    };

    // 2. 处理预检请求 (OPTIONS)
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    const url = new URL(request.url);
    let targetUrl = "";

    // 3. 智能判断目标地址
    // 获取域名后面的路径部分，并去除首个斜杠
    // script.js 在请求 NAI 时会进行 encodeURIComponent，所以这里要解码
    const rawPath = url.pathname.substring(1) + url.search;
    const decodedPath = decodeURIComponent(rawPath);

    if (decodedPath.startsWith("http")) {
      // 情况 A: 如果路径本身就是一个 http 开头的完整网址（用于 NovelAI, ImgBB 等）
      // 例如: https://your-worker.dev/https://api.novelai.net/ai/generate
      targetUrl = decodedPath;
    } else {
      // 情况 B: 之前配置的 GitHub 备份逻辑（只传了路径）
      // 例如: https://your-worker.dev/repos/user/repo...
      // 默认为 GitHub
      targetUrl = "https://api.github.com" + url.pathname + url.search;
    }

    // 4. 创建新请求
    const newRequest = new Request(targetUrl, {
      method: request.method,
      headers: request.headers,
      body: request.body,
    });

    // 5. 处理 Headers
    // GitHub 需要 User-Agent
    newRequest.headers.set("User-Agent", "Cloudflare-Worker-Proxy");
    
    // 清理 Host 头，防止 Cloudflare 报错，让 fetch 自动处理
    // (Cloudflare 有时会禁止手动修改 Host 为某些值，删除最安全)
    newRequest.headers.delete("Host"); 

    // 6. 发送请求并返回结果
    try {
      const response = await fetch(newRequest);
      
      // 重新构建响应，注入 CORS 头
      const newResponse = new Response(response.body, response);
      for (const [key, value] of Object.entries(corsHeaders)) {
        newResponse.headers.set(key, value);
      }

      return newResponse;
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message, target: targetUrl }), { 
        status: 500,
        headers: corsHeaders
      });
    }
  },
};